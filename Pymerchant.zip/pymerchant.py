from view import View


def main():
    console = View()
    console.game_loop()


if __name__ == "__main__":
    main()
